// js/main.js
document.addEventListener('DOMContentLoaded', function () {

  /* ACCORDION */
  document.querySelectorAll('.accordion').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('active');
      const panel = btn.nextElementSibling;
      if (panel.style.maxHeight) panel.style.maxHeight = null;
      else panel.style.maxHeight = panel.scrollHeight + 'px';
    });
  });

  /* LIGHTBOX for images with .lightbox-trigger */
  const lightbox = document.getElementById('lightbox');
  const lbImg = document.getElementById('lightbox-image');
  const lbCaption = document.getElementById('lightbox-caption');
  if (lightbox) {
    document.querySelectorAll('.lightbox-trigger').forEach(img => {
      const clickHandler = (ev) => {
        lbImg.src = img.src;
        lbImg.alt = img.alt || '';
        lbCaption.textContent = img.alt || '';
        lightbox.style.display = 'block';
        lightbox.setAttribute('aria-hidden','false');
      };
      img.addEventListener('click', clickHandler);
      img.addEventListener('keypress', function(e){ if (e.key === 'Enter') clickHandler(e); });
    });
    const closeBtn = document.getElementById('lightbox-close');
    closeBtn && closeBtn.addEventListener('click', ()=> {
      lightbox.style.display = 'none';
      lightbox.setAttribute('aria-hidden','true');
    });
  }

  /* PRODUCT SEARCH + SORT (products.html) */
  const searchInput = document.getElementById('product-search');
  const productList = document.getElementById('product-list');
  const sortSelect = document.getElementById('sort-select');
  if (searchInput && productList) {
    const items = Array.from(productList.querySelectorAll('.product'));
    const render = (filterText = '') => {
      const ft = filterText.trim().toLowerCase();
      let filtered = items.filter(it => it.dataset.title.toLowerCase().includes(ft));
      // sort
      if (sortSelect) {
        const s = sortSelect.value;
        if (s === 'price-asc') filtered.sort((a,b)=> parseFloat(a.dataset.price)-parseFloat(b.dataset.price));
        if (s === 'price-desc') filtered.sort((a,b)=> parseFloat(b.dataset.price)-parseFloat(a.dataset.price));
      }
      productList.innerHTML = '';
      filtered.forEach(i => productList.appendChild(i));
    };
    searchInput.addEventListener('input', e => render(e.target.value));
    sortSelect && sortSelect.addEventListener('change', ()=> render(searchInput.value));
  }

  /* ENQUIRY FORM: show/hide conditional sections */
  const enqType = document.getElementById('enq-type');
  if (enqType) {
    enqType.addEventListener('change', (e)=>{
      const val = e.target.value;
      document.querySelectorAll('.conditional').forEach(el=> el.hidden = true);
      if (val === 'product') document.getElementById('product-section').hidden = false;
      if (val === 'volunteer') document.getElementById('volunteer-section').hidden = false;
    });
  }

  /* Leaflet map init if #map present */
  if (document.getElementById('map') && typeof L !== 'undefined') {
    try {
      const map = L.map('map').setView([-33.9253, 18.4239], 13); // Cape Town coords as example
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);
      L.marker([-33.9253, 18.4239]).addTo(map).bindPopup('Retailability store').openPopup();
    } catch (err) {
      console.warn('Leaflet map failed to init', err);
    }
  }

  /* Enquire button quick action (products list) */
  document.querySelectorAll('.enquire-btn').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const product = btn.dataset.product || '';
      // open enquiry page with product prefilled (simple)
      window.location = 'enquiry.html?product=' + encodeURIComponent(product);
    });
  });

  /* Pre-fill enquiry product from query string */
  const params = new URLSearchParams(window.location.search);
  const preProd = params.get('product');
  if (preProd) {
    const pInput = document.getElementById('enq-product');
    const pType = document.getElementById('enq-type');
    if (pInput) pInput.value = preProd;
    if (pType) { pType.value = 'product'; pType.dispatchEvent(new Event('change')); }
  }

});

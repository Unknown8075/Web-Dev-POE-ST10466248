// js/forms.js
document.addEventListener('DOMContentLoaded', function () {

  /* CONTACT FORM: client-side validation and email compose fallback */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function (ev) {
      ev.preventDefault();
      const name = contactForm.querySelector('[name="name"]').value.trim();
      const email = contactForm.querySelector('[name="email"]').value.trim();
      const message = contactForm.querySelector('[name="message"]').value.trim();
      const phone = contactForm.querySelector('[name="phone"]').value.trim();
      if (!name || !email || !message || message.length < 10) {
        document.getElementById('contact-form-feedback').textContent = 'Please complete all required fields with valid information.';
        return;
      }
      // Compose mailto body (fallback)
      const subject = encodeURIComponent('Website Contact: ' + name);
      const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nMessage:\n${message}`);
      // If you have a server endpoint, you would use fetch() here. For now use mailto fallback:
      window.location.href = `mailto:info@example.com?subject=${subject}&body=${body}`;
      document.getElementById('contact-form-feedback').textContent = 'Opening your email client to send the message...';
    });
  }

  /* ENQUIRY FORM: validation, calculate simple quote and show confirmation */
  const enqForm = document.getElementById('enquiry-form');
  if (enqForm) {
    enqForm.addEventListener('submit', function (ev) {
      ev.preventDefault();
      const name = enqForm.querySelector('#enq-name').value.trim();
      const email = enqForm.querySelector('#enq-email').value.trim();
      const type = enqForm.querySelector('#enq-type').value;
      const qty = parseInt(enqForm.querySelector('#enq-qty')?.value || '1', 10);
      const product = enqForm.querySelector('#enq-product')?.value || '';
      const message = enqForm.querySelector('#enq-message').value.trim();

      if (!name || !email || !type) {
        document.getElementById('enquiry-feedback').textContent = 'Please fill name, email and enquiry type.';
        return;
      }

      // Basic mock pricing: if product, pick price from dataset (or use dataset via data attributes in products page).
      let quoteText = '';
      if (type === 'product') {
        const price = 499; // placeholder unit price. Replace with real value or lookup via product ID.
        const total = price * (isNaN(qty) ? 1 : qty);
        quoteText = `Estimated cost for ${qty} × ${product} is R${total}. (This is an estimate.)`;
      } else if (type === 'volunteer') {
        quoteText = `Thanks for your interest in volunteering. We'll be in touch about availability.`;
      } else if (type === 'sponsor') {
        quoteText = `Thanks for interest in sponsorship. We'll contact you with sponsorship packages.`;
      } else {
        quoteText = `Thanks for your enquiry. We'll contact you about next steps.`;
      }

      // Display confirmation to the user and simulate AJAX success
      document.getElementById('enquiry-feedback').textContent = 'Processing enquiry...';
      setTimeout(()=> {
        document.getElementById('enquiry-feedback').textContent = 'Enquiry submitted. ' + quoteText;
        enqForm.reset();
      }, 700);
    });
  }

});
